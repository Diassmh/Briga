# BuscaCorna aprimorada

Esta versão parte diretamente do código **Briga Pinhão** e mantém o estilo original: funções simples, nomes em português, máquina de estados explícita e comentários próximos da lógica que explicam.

O objetivo não foi reescrever o projeto inteiro. Foram corrigidos os problemas da BuscaCorna e adaptada a mira do modo R/C para a configuração nova de sensores.

## Resumo do comportamento

```text
BUSCAR
  -> JSumo lateral encontrou: virar para aquele lado
  -> IR frontal encontrou: alinhar
  -> não encontrou por um tempo: avançar um pouco e procurar novamente

ALINHAR_FRENTE
  -> corrigir com os três IRs frontais
  -> centralizou: esperar o adversário

ESPERAR_ALVO
  -> continua centralizado: espera 400 ms
  -> saiu do centro: volta a alinhar
  -> perdeu pela lateral: acompanha com o JSumo

AVANCAR_LENTO
  -> aproxima usando os IRs para corrigir a direção
  -> perdeu o alvo por um instante: mantém o movimento por pouco tempo
  -> perdeu de verdade: volta a buscar

ATAQUE_RAPIDO
  -> continua usando a lógica de fotoresistor que já existia

PRIORIDADE DE COMBATE
  -> IR frontal central detectando: continua a acao atual, mesmo sobre a linha
  -> IR frontal central desligado e linha detectada: executa a recuperacao
```

## 1. BuscaCorna como padrão, sem apagar a busca antiga

A variável `ModoBusca` agora começa em `Corna`.

A busca ofensiva antiga continua no projeto e ainda pode ser escolhida com `O`. A BuscaCorna pode ser escolhida com `I`.

Isso foi feito de forma conservadora: a busca nova é o padrão, mas o código antigo não foi apagado.

**Atenção:** a busca ofensiva é legado e ainda usa a lógica dos três JSumos antigos. Ela não foi adaptada para a configuração nova.

## 2. Temporizador da busca corrigido

Antes, `tempoBusca` começava em zero e não era reiniciado corretamente. Depois de passar alguns segundos no menu, o robô podia entrar em `AVANCAR_LENTO` quase imediatamente.

Agora:

- o tempo é iniciado quando a luta realmente começa;
- toda volta para `BUSCAR` reinicia `tempoBusca`;
- os tempos ficaram concentrados em `defines.hpp`.

Não foi criada uma estrutura genérica de temporizadores. Foram corrigidos apenas os pontos necessários.

## 3. Sensores frontais têm prioridade sobre os laterais

Antes, um JSumo lateral podia mandar o robô girar mesmo com o adversário já detectado na frente.

Agora a ordem é:

```text
1. IRs frontais
2. JSumos laterais
3. última direção conhecida
```

Os JSumos servem para encontrar de qual lado vem o adversário. Quando algum IR frontal detecta, o alinhamento frontal assume o controle.

## 4. Transferência do JSumo lateral para os IRs frontais

Foram adicionados dois estados:

```cpp
TRANSFERIR_LATERAL_E
TRANSFERIR_LATERAL_D
```

Exemplo pela esquerda:

```text
JSumo esquerdo detecta
-> o Briga gira para a esquerda
-> o JSumo deixa de detectar
-> o Briga continua girando para a esquerda, mas mais devagar
-> espera o adversário aparecer nos IRs frontais
```

Isso evita que o robô abandone o adversário no espaço entre o sensor lateral a 90 graus e os sensores da frente.

Se nenhum frontal aparecer até o fim da janela de transferência, o robô volta para `BUSCAR` no mesmo lado.

## 5. Aproximação lenta agora continua alinhando

Antes, o estado `AVANCAR_LENTO` executava somente:

```cpp
moverMotores(60, 60);
```

O robô avançava reto mesmo que o adversário se deslocasse.

Agora:

- frontal central: avança reto;
- frontal esquerdo: diminui o motor esquerdo e faz arco para a esquerda;
- frontal direito: diminui o motor direito e faz arco para a direita;
- ambos os motores continuam para frente durante a aproximação;
- uma falha muito curta de leitura não faz o robô desistir imediatamente;
- perda real do alvo faz o robô voltar para a busca.

## 6. IR frontal central tem prioridade sobre a linha

A primeira versao fazia qualquer leitura da faixa branca interromper a luta, inclusive durante um empurrao. Isso podia fazer o Briga dar re justamente quando o adversario ja estava na rampa.

Agora a regra e simples:

```text
IR frontal central detectando
  -> o Briga continua o estado atual
  -> os sensores de linha nao iniciam a recuperacao

IR frontal central desligado + linha detectada
  -> entra em RECUPERAR_LINHA
```

Somente o IR central recebe essa prioridade. Os IRs frontal esquerdo e direito continuam sendo usados para alinhamento, mas nao fazem o robo ignorar a linha.

Se a recuperacao ja tiver comecado e o IR central voltar a detectar o adversario, o codigo cancela a fuga e retoma o estado anterior. Assim, se o Briga estava em `ATAQUE_RAPIDO`, ele volta ao ataque; se estava aproximando ou alinhando, retoma aquela etapa.

Quando o IR central deixa de detectar, a protecao da linha volta a funcionar imediatamente. A recuperacao continua dividida em tres etapas:

```text
1. RECUANDO_DA_LINHA
2. GIRANDO_PARA_DENTRO
3. CONFIRMANDO_PISO
```

Comportamento quando a recuperacao realmente e acionada:

- linha esquerda: recua e gira para a direita;
- linha direita: recua e gira para a esquerda;
- duas linhas: recua por mais tempo e escolhe um lado contrario a ultima perseguicao;
- so volta a buscar depois de confirmar que os dois sensores estao novamente no preto;
- se a recuperacao passar de um segundo, os motores param e o codigo informa erro pelo Bluetooth.

A logica do fotoresistor nao foi alterada. Esta mudanca trata somente da disputa de prioridade entre o IR central e os sensores de linha.

## 7. Leituras dos sensores agrupadas

A task lê todos os sensores em variáveis locais e publica os valores juntos dentro de uma seção crítica curta.

A BuscaCorna copia uma única estrutura `LeituraSensores` antes de decidir.

Explicação simples:

> Cada decisão usa uma fotografia completa dos sensores, em vez de misturar leituras de dois momentos diferentes.

A task de sensores deixou de alterar `lado`. Agora ela apenas mede. A decisão sobre esquerda e direita fica na própria lógica da busca.

## 8. Mira assistida do R/C adaptada

A mira antiga usava:

```text
JSumo esquerdo + JSumo frontal + JSumo direito
```

O novo robô não possui essa distribuição. A mira agora usa:

```text
IR frontal esquerdo + IR frontal central + IR frontal direito
```

Quando a mira está ligada:

- centro: mantém os dois motores iguais;
- esquerda: reduz o motor esquerdo;
- direita: reduz o motor direito;
- centro mais lateral: faz uma correção menor;
- o valor do R2 continua controlando a velocidade.

O comando de mira rápida no botão `Circle` também foi adaptado para os IRs frontais.

## 9. Correções pequenas nas aberturas antigas

As aberturas continuam disponíveis, mas a opção padrão passou a ser `z`, que não faz uma movimentação inicial.

Também foram corrigidos problemas claros do `switch` antigo:

- adicionados `break` que estavam faltando;
- a abertura `A` não fica mais presa caso `lado == frente`;
- o antigo comando `j`, que fazia o robô avançar para sempre, foi desativado com os motores parados.

Essas aberturas ainda usam `delay()` e não foram convertidas para a máquina de estados. Devem ser testadas separadamente antes de voltar a usá-las em competição.

## Parâmetros para calibração

Os valores da BuscaCorna estão reunidos em `include/defines.hpp`:

```cpp
LIMIAR_LINHA_E
LIMIAR_LINHA_D

VEL_BUSCA
VEL_GIRO_LATERAL
VEL_TRANSFERENCIA
VEL_APROXIMACAO
VEL_APROXIMACAO_LENTA
VEL_APROXIMACAO_RAPIDA

TEMPO_BUSCA_MS
TEMPO_AVANCO_SEM_ALVO_MS
TEMPO_PERDA_ALVO_MS
TEMPO_TRANSFERENCIA_MS

TEMPO_RECUO_LINHA_MS
TEMPO_RECUO_DUAS_LINHAS_MS
TEMPO_GIRO_LINHA_MS
TEMPO_CONFIRMA_PISO_MS
TEMPO_MAX_RECUPERACAO_MS
```

São valores iniciais. A estrutura do código está pronta, mas velocidades, limiares e tempos precisam ser ajustados com o robô montado.

## O que foi mantido de propósito

Conforme decidido, esta versão **não altera**:

- o conflito provisório entre `IR` e `pinoLDR`, ambos no GPIO 13;
- a forma como o fotoresistor libera e encerra `ATAQUE_RAPIDO`;
- a calibração inicial do fotoresistor;
- a parada por controle que chama `ESP.restart()`;
- a função `moverMotores()` e a faixa dos valores enviados;
- a opção de manter a busca ofensiva antiga no projeto.

Esses pontos precisam ser tratados separadamente quando a montagem elétrica e o funcionamento do fotoresistor estiverem definidos.

## Testes mínimos no robô

1. Confirmar os valores dos sensores de linha sobre preto e branco.
2. Testar linha esquerda, direita e as duas juntas com as rodas suspensas.
3. Testar a transferência JSumo esquerdo -> IR frontal esquerdo.
4. Testar a transferência JSumo direito -> IR frontal direito.
5. Verificar se `AVANCAR_LENTO` corrige para os dois lados.
6. Testar a mira assistida do R/C em baixa velocidade.
7. Somente depois ajustar velocidades e tempos.
8. Corrigir o pino compartilhado entre receptor do controle e LDR antes de ligar os dois circuitos juntos.

## Validação desta alteração

O projeto completo passou por verificação sintática com GCC e Clang usando stubs locais das bibliotecas do ESP32. O único aviso foi o parâmetro padrão não utilizado da função da task de sensores.

Também foram executados seis testes específicos da nova prioridade:

1. `ATAQUE_RAPIDO` + IR central + linha mantém o ataque;
2. a mesma linha inicia a recuperação quando o IR central está desligado;
3. o IR central cancela uma recuperação já iniciada e retoma o estado anterior;
4. os IRs esquerdo e direito não ignoram a linha;
5. quando o IR central apaga, a linha assume no ciclo seguinte;
6. durante a busca, IR central + linha leva ao alinhamento, não à recuperação.

Os seis testes passaram com GCC e Clang.

O build real do PlatformIO ainda deve ser executado no computador da equipe com as bibliotecas do ESP32 instaladas.
